%% 5.

% Constantes
sol = 1;
nuvens = 2;
chuva = 3;

%% 5.a)

T = [ 0.7 0.2 0.1
      0.2 0.3 0.5
      0.3 0.3 0.4]';

% Matriz estocastica -> soma das colunas = 1
% abs(sum(T) - 1) < 1e-10, pois o matlab faz calculo numerico
% entao ele pode considerar (por exemplo) 1 ~= 0.99999999
% para facilitar os arredondamentos
if all(abs(sum(T) - 1) < 1e-10) & all(T>=0) & all(T<=1)
    disp("A matriz e estocastica!")
end

%% 5.b)

v0 = [1 0 0]';
v1 = T^1 * v0;
% ou
T1 = T^1;
fprintf("5.c) segundo dia - p(sol) = %.8f, p(nuvens) = %.8f, p(chuva) = %.8f\n",T1(:,sol));


