function BloomFilter = inicializarFiltro(n)
    % inicializar array de n elementos com valor 0

    BloomFilter = zeros(n,1,'uint8'); % deveria ser apenas 1 bit, mas nao existe
end